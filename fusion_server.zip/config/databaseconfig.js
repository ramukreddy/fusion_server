module.exports = {

    host: process.env.RDS_HOSTNAME || "aagon2tmmi4qxl.cq6lnlnndh44.us-east-1.rds.amazonaws.com",
    user: process.env.RDS_USERNAME || "fusionserver",
    password: process.env.RDS_PASSWORD|| "fusionserver",
    database: process.env.RDS_DB_NAME || "ebdb"
};